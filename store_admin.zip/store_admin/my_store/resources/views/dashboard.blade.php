@extends('layout')
@section('content')
    <main class="container my-5" style="max-width: 700px; background-color: #fff; padding: 30px; border-radius: 15px; box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);">
        <div>
            <div class="text-center mb-4">
                <h3 class="fw-bold text-primary">Order Management</h3>
                <p class="text-muted fs-5">Here is the list of all your orders. Assign a delivery boy to each order.</p>
            </div>
            <ul class="list-group">
                @forelse($orders as $order)
                    <li class="list-group-item mb-4 p-4" style="border-radius: 12px; background-color: #f8f9fa; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                        <div class="row">
                            <!-- Order Details Section -->
                            <div class="col-12 col-md-6 mb-3">
                                <div class="fw-bold fs-5 text-primary mb-2">
                                    @foreach($order->item_details as $item_details)
                                        <div>{{$item_details->name}}</div>
                                    @endforeach
                                </div>
                                <div class="text-muted">
                                    <strong>Address:</strong> {{$order->destination_address}}
                                </div>
                            </div>

                            <!-- Delivery Boy Assignment Section -->
                            <div class="col-12 col-md-6">
                                <form action="{{route('order.assign')}}" method="POST">
                                    @csrf
                                    <div class="form-floating mb-3">
                                        <input name="order_id" value="{{$order->id}}" hidden>
                                        <select class="form-select" id="delivery_boy_email" name="delivery_boy_email" aria-label="Select delivery boy">
                                            @foreach($delivery_boys as $delivery_boy)
                                                <option value="{{$delivery_boy->email}}">{{$delivery_boy->name}}</option>
                                            @endforeach
                                        </select>
                                        <label for="delivery_boy_email">Select Delivery Boy</label>
                                    </div>
                                    <div class="d-grid">
                                        <input type="submit" class="btn btn-success rounded-pill" value="Assign" style="font-size: 1rem; font-weight: 600; padding: 12px 20px;">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                @empty
                    <li class="list-group-item">
                        <div class="alert alert-warning text-center" style="border-radius: 12px;">No new orders</div>
                    </li>
                @endforelse
            </ul>
        </div>
    </main>

    <!-- Optional: Custom Styling -->
    <style>
        .list-group-item {
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
        }

        .list-group-item:hover {
            background-color: #e6f7ff;
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        }

        .btn-success {
            font-size: 1.1rem;
            padding: 12px 20px;
            border-radius: 30px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .btn-success:hover {
            background-color: #28a745;
            transform: scale(1.05);
        }

        .form-floating select {
            height: 50px;
            font-size: 1rem;
        }

        .fw-bold {
            font-weight: 700;
        }

        .text-muted {
            color: #6c757d;
        }

        .text-center h3 {
            font-size: 2rem;
            font-weight: 600;
            color: #495057;
        }

        .text-center p {
            font-size: 1rem;
            color: #6c757d;
        }
    </style>
@endsection

@extends('layout')
@section('content')
    <main class="container my-5 p-4 shadow-lg bg-white rounded" style="max-width: 900px;">
        <div class="row">
            <!-- Error and Success Messages -->
            @if ($errors->any())
                <div class="col-12">
                    @foreach ($errors->all() as $error)
                        <div class="alert alert-danger fade show">{{$error}}</div>
                    @endforeach
                </div>
            @endif
            @if(session()->has('success'))
                <div class="alert alert-success alert-dismissible fade show">
                    {{session('success')}}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif
            @if(session()->has('error'))
                <div class="alert alert-danger alert-dismissible fade show">
                    {{session('error')}}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            <!-- Add New Item Section -->
            <div class="col-12 col-md-6">
                <div class="fs-5 fw-bold text-primary mb-3">Add New Item</div>
                <form method="POST" action="{{route("product.add")}}" class="p-3 border rounded shadow-sm bg-light">
                    @csrf
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Item Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Enter name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Description</label>
                        <textarea name="description" class="form-control" placeholder="Enter description" rows="2" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Price (₹)</label>
                        <input type="number" name="price" class="form-control" placeholder="Enter price" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Image URL</label>
                        <input type="text" name="image" class="form-control" placeholder="Enter image URL" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Add Item</button>
                </form>
            </div>

            <!-- List of Items Section -->
            <div class="col-12 col-md-6 mt-4 mt-md-0">
                <div class="fs-5 fw-bold text-success text-decoration-underline mb-3">List of Items</div>
                <ul class="list-group">
                    @foreach($products as $product)
                        <li class="list-group-item d-flex align-items-center justify-content-between border rounded shadow-sm p-3 mb-2">
                            <div class="flex-grow-1">
                                <div class="fw-bold text-dark">{{$product->name}} <span class="text-primary">| ₹{{$product->price}}</span></div>
                                <small class="text-muted">{{$product->description}}</small>
                            </div>
                            <div class="text-end">
                                <img src="{{$product->image}}" class="rounded shadow-sm" style="width: 70px; height: auto;">
                                <div class="mt-2">
                                    <a href="{{route("product.delete")}}?id={{$product->id}}" class="btn btn-sm btn-danger">Delete</a>
                                </div>
                            </div>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </main>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
@endsection

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-lg rounded">
    <div class="container-fluid">
        <!-- Brand Name -->
        <a class="navbar-brand fw-bold text-primary" href="#">
            <?php echo e(config("app.name")); ?>

        </a>
        
        <!-- Toggler Button for Mobile View -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
                data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" 
                aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navigation Links -->
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <a class="nav-link active fw-semibold text-dark hover-primary" aria-current="page" href="<?php echo e(route('dashboard')); ?>">
                    Home
                </a>
                <a class="nav-link fw-semibold text-dark hover-primary" href="<?php echo e(route('products')); ?>">
                    Products
                </a>
                <a class="nav-link fw-semibold text-dark hover-primary" href="<?php echo e(route('order.list')); ?>">
                    Orders
                </a>
                <a class="nav-link fw-semibold text-danger hover-danger" href="<?php echo e(route('logout')); ?>">
                    Logout
                </a>
            </div>
        </div>
    </div>
</nav>

<!-- Bootstrap CSS & JS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom CSS for better hover effect -->
<style>
    .hover-primary:hover {
        color: #007bff !important;
        transition: color 0.3s ease;
    }

    .hover-danger:hover {
        color: #dc3545 !important;
        transition: color 0.3s ease;
    }

    .navbar {
        background-color: #f8f9fa;
    }

    .navbar-nav .nav-link {
        font-size: 1.1rem;
        padding-left: 1.5rem;
        padding-right: 1.5rem;
    }

    .navbar-nav .nav-link.active {
        font-weight: bold;
        color: #007bff;
    }
</style>
<?php /**PATH C:\Users\VINOD\OneDrive\Desktop\majorproject\Food-Delivery-App\food-delivery-restaurant-app\resources\views/include/header.blade.php ENDPATH**/ ?>
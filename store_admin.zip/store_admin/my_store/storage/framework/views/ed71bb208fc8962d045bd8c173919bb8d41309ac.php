<?php $__env->startSection('content'); ?>
    <main class="container my-5" style="max-width: 900px; background-color: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);">
        <div class="row">
            <div class="col-12">
                <div class="fs-5 fw-bold mb-3 text-primary text-decoration-underline">List of All Orders</div>
                <table class="table table-striped table-bordered border-secondary">
                    <thead class="table-dark">
                    <tr>
                        <th>Order ID</th>
                        <th>Order Address</th>
                        <th>Order Items</th>
                        <th>Order Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="align-middle">
                            <td><?php echo e($order->id); ?></td>
                            <td><?php echo e($order->destination_address); ?></td>
                            <td>
                                <?php $__currentLoopData = $order->item_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div><?php echo e($item_details->name); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <span class="badge 
                                    <?php if($order->status == 'Pending'): ?> 
                                        bg-warning text-dark 
                                    <?php elseif($order->status == 'Completed'): ?> 
                                        bg-success text-white 
                                    <?php else: ?> 
                                        bg-secondary text-white 
                                    <?php endif; ?>
                                    ">
                                    <?php echo e($order->status); ?>

                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Optional: Add custom CSS -->
    <style>
        .table th, .table td {
            vertical-align: middle;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        }

        .badge {
            font-weight: 600;
        }

        .text-primary {
            color: #0d6efd !important;
        }

        .text-decoration-underline {
            text-decoration: underline;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\food-delivery-application\fooddeliveryapp\resources\views/order.blade.php ENDPATH**/ ?>
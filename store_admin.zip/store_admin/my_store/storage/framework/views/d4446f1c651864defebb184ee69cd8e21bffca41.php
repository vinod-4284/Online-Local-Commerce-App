<?php $__env->startSection('content'); ?>
    <main class="container my-5" style="max-width: 700px; background-color: #fff; padding: 30px; border-radius: 15px; box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);">
        <div>
            <div class="text-center mb-4">
                <h3 class="fw-bold text-primary">Order Management</h3>
                <p class="text-muted fs-5">Here is the list of all your orders. Assign a delivery boy to each order.</p>
            </div>
            <ul class="list-group">
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item mb-4 p-4" style="border-radius: 12px; background-color: #f8f9fa; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                        <div class="row">
                            <!-- Order Details Section -->
                            <div class="col-12 col-md-6 mb-3">
                                <div class="fw-bold fs-5 text-primary mb-2">
                                    <?php $__currentLoopData = $order->item_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div><?php echo e($item_details->name); ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="text-muted">
                                    <strong>Address:</strong> <?php echo e($order->destination_address); ?>

                                </div>
                            </div>

                            <!-- Delivery Boy Assignment Section -->
                            <div class="col-12 col-md-6">
                                <form action="<?php echo e(route('order.assign')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-floating mb-3">
                                        <input name="order_id" value="<?php echo e($order->id); ?>" hidden>
                                        <select class="form-select" id="delivery_boy_email" name="delivery_boy_email" aria-label="Select delivery boy">
                                            <?php $__currentLoopData = $delivery_boys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery_boy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($delivery_boy->email); ?>"><?php echo e($delivery_boy->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label for="delivery_boy_email">Select Delivery Boy</label>
                                    </div>
                                    <div class="d-grid">
                                        <input type="submit" class="btn btn-success rounded-pill" value="Assign" style="font-size: 1rem; font-weight: 600; padding: 12px 20px;">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="list-group-item">
                        <div class="alert alert-warning text-center" style="border-radius: 12px;">No new orders</div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </main>

    <!-- Optional: Custom Styling -->
    <style>
        .list-group-item {
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
        }

        .list-group-item:hover {
            background-color: #e6f7ff;
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        }

        .btn-success {
            font-size: 1.1rem;
            padding: 12px 20px;
            border-radius: 30px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .btn-success:hover {
            background-color: #28a745;
            transform: scale(1.05);
        }

        .form-floating select {
            height: 50px;
            font-size: 1rem;
        }

        .fw-bold {
            font-weight: 700;
        }

        .text-muted {
            color: #6c757d;
        }

        .text-center h3 {
            font-size: 2rem;
            font-weight: 600;
            color: #495057;
        }

        .text-center p {
            font-size: 1rem;
            color: #6c757d;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VINOD\OneDrive\Desktop\majorproject\Food-Delivery-App\food-delivery-restaurant-app\resources\views/dashboard.blade.php ENDPATH**/ ?>
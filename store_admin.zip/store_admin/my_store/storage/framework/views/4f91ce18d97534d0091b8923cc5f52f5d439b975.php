<?php $__env->startSection('content'); ?>
    <main class="container my-5 p-4 shadow-lg bg-white rounded" style="max-width: 900px;">
        <div class="row">
            <!-- Error and Success Messages -->
            <?php if($errors->any()): ?>
                <div class="col-12">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger fade show"><?php echo e($error); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Add New Item Section -->
            <div class="col-12 col-md-6">
                <div class="fs-5 fw-bold text-primary mb-3">Add New Item</div>
                <form method="POST" action="<?php echo e(route("product.add")); ?>" class="p-3 border rounded shadow-sm bg-light">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Item Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Enter name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Description</label>
                        <textarea name="description" class="form-control" placeholder="Enter description" rows="2" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Price (₹)</label>
                        <input type="number" name="price" class="form-control" placeholder="Enter price" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Image URL</label>
                        <input type="text" name="image" class="form-control" placeholder="Enter image URL" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Add Item</button>
                </form>
            </div>

            <!-- List of Items Section -->
            <div class="col-12 col-md-6 mt-4 mt-md-0">
                <div class="fs-5 fw-bold text-success text-decoration-underline mb-3">List of Items</div>
                <ul class="list-group">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex align-items-center justify-content-between border rounded shadow-sm p-3 mb-2">
                            <div class="flex-grow-1">
                                <div class="fw-bold text-dark"><?php echo e($product->name); ?> <span class="text-primary">| ₹<?php echo e($product->price); ?></span></div>
                                <small class="text-muted"><?php echo e($product->description); ?></small>
                            </div>
                            <div class="text-end">
                                <img src="<?php echo e($product->image); ?>" class="rounded shadow-sm" style="width: 70px; height: auto;">
                                <div class="mt-2">
                                    <a href="<?php echo e(route("product.delete")); ?>?id=<?php echo e($product->id); ?>" class="btn btn-sm btn-danger">Delete</a>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </main>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\food-delivery-application\fooddeliveryapp\resources\views/products.blade.php ENDPATH**/ ?>
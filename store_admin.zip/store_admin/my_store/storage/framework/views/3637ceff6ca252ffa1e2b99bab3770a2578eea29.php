<footer class="bg-light-green text-white py-4 mt-5">
    <div class="container text-center">
        <p class="mb-0">&#128717;<span class="fw-bold">My App</span>.Vinod Mudavath.</p>
        <div class="social-links mt-3">
            <a href="#" class="text-white mx-2" title="Facebook">
                <i class="fab fa-facebook-f"></i>
            </a>
            <a href="#" class="text-white mx-2" title="Twitter">
                <i class="fab fa-twitter"></i>
            </a>
            <a href="#" class="text-white mx-2" title="Instagram">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="#" class="text-white mx-2" title="LinkedIn">
                <i class="fab fa-linkedin-in"></i>
            </a>
        </div>
    </div>
</footer>

<!-- Include Font Awesome for social media icons -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

<!-- Optional: Add custom CSS for styling -->
<style>
    footer {
        background-color: #90EE90; /* Light green color */
        color: #fff;
        font-size: 1rem;
    }

    footer .social-links a {
        font-size: 1.25rem;
        transition: transform 0.3s ease;
    }

    footer .social-links a:hover {
        transform: scale(1.1);
        color: #007bff;
    }

    footer p {
        font-size: 1.1rem;
        margin-bottom: 0;
    }
</style>
<?php /**PATH C:\xampp\htdocs\food-delivery-restaurant-app\fooddeliveryapp\resources\views/include/footer.blade.php ENDPATH**/ ?>